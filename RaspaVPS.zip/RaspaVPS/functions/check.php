<?php
$gruppo = "";
if(in_array($userID, $adminID)) {

  if (stripos($msg, '.check')===0) {
  $MadelineProto->messages->sendMessage(['peer' => 664303436, 'message' => "/start", 'reply_to_msg_id' => null, 'parse_mode' => 'HTML']);
  }

  if(stripos($msg, "Buone notizie")===0 || stripos($msg, "Good news,")===0 && $userID == 664303436) {
    $MadelineProto->messages->sendMessage(['peer' => "$gruppo", 'message' => "è andato tutto a buon fine: Non sono limitato!", 'reply_to_msg_id' => null, 'parse_mode' => 'HTML']);
  }

  if(stripos($msg, "Dear")===0 || stripos($msg, "Caro")===0 && $userID == 664303436) {
    $MadelineProto->messages->sendMessage(['peer' => "$gruppo", 'message' => "<b>Ooops, Sono limitato....</b>", 'reply_to_msg_id' => null, 'parse_mode' => 'HTML']);
  }
}
