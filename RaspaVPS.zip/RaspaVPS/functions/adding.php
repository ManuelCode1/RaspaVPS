<?php

# USERSTORM
if(in_array($userID, $adminID)){
  //ESCI
  if(stripos($msg,'.esci')===0)
  {
    $e = explode(' ',$msg,2);
    $chat = $e['1'];
    $MadelineProto->channels->leaveChannel(['channel'=>$chat]);
    $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "<b>Sono uscito da:</b> $chat.", 'parse_mode' => 'HTML']);
  }

  //ENTRA
  if(stripos($msg,'.entra')===0)
  {
    $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "Entro nel gruppo di <b>git-hub</b>.", 'parse_mode' => 'HTML']);
    try{ $MadelineProto->channels->joinChannel(['channel'=>explode(' ',$msg)[1]]); }catch(Exception $e){}
  }
}
