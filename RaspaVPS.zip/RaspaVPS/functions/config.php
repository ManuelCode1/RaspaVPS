<?php
if(in_array($userID, $adminID))
{
  $nomi = ['Giovanni.', 'Lorenzo.', 'Andrea.', 'Marco.', 'Matteo.', 'Mattia.', 'Riccardo.', 'Daniele.', 'Luca.', 'Mario.'];
  //SETNOME
  if(stripos($msg,'.rnome')===0) {
    $nome = $nomi[array_rand($nomi)];
    $MadelineProto->account->updateProfile(['first_name' => "$nome", 'last_name' => "", 'about' => "Ciao! sono $nome", ]);
  }

  //GRUPPI
  if(stripos($msg, ".grupz")===0) {
    $chats = $MadelineProto->getDialogs()['channel_id'];
    foreach($chats as $chat) {
      $lista .= "\n$chat";
    }
    $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "$lista", 'parse_mode' => 'HTML']);
  }
}
