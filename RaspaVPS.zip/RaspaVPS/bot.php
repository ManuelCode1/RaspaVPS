<?php
$bot = function ($update) use (&$MadelineProto, &$schedule, &$me, &$restart, &$sm) {
    foreach ($update as $varname => $var) { if ($varname !== 'update') $$varname = $var; }

  $adminID = [ILTUOID];
  /*
  $functions = glob('./functions/*.php');
  foreach ($functions as $file) {
    include("$file");
  }
  */
  //BASE COMMANDS
  if(in_array($userID,$adminID)) {
    //RDY (CONTROLLO)
    if ($msg == '.rdy') {
      $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "<b>[Adder] </b><i>Ready</i>", 'parse_mode' => 'HTML'], ['noResponse' => true]);
    }
    //NUMERO
    if (stripos($msg,'.numero')===0) {
      $ver = yield $MadelineProto->getSelf()['phone'];
      yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "+$ver", 'parse_mode' => 'HTML']);
    }
    #GRAB
    if(strpos($msg,'.gpl ') === 0) {
      if(isset(explode(' ', $msg)[1])) $grab = explode(' ', $msg)[1]; else $grab = $chatID;
		  yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "Mi sto avviando...", 'parse_mode' => 'HTML']);
		  yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => $grab]);
		  $idl = [];
		  try{
        yield $MadelineProto->channels->joinChannel(['channel'=> $grab]);
		  } catch (Exception $e) {
        yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => $e->getMessage(), 'parse_mode' => 'HTML']);
		  }
		  $n = 0;
		  $pwr = yield $MadelineProto->getPwrChat($grab);
		  print(json_encode($pwr));
		  foreach($pwr['participants'] as $pwr) {
        if($pwr['user']['type'] == 'user') {
          $uh = $pwr['user']['id'];
          $idl[] = "\n$uh";
        }
        $n++;
      }
      file_put_contents("add.txt", $idl);
      yield $MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "Ho caricato <b>$n</b> membri", 'parse_mode' => 'HTML']);
	  }

    //RASPA
    if(stripos($msg,'.raspa')===0) {
      $a=file_get_contents("add.txt");
      $b=explode("\n",$a);
      shuffle($b);
      foreach ($b as $id) {
        try {
          yield $MadelineProto->channels->inviteToChannel(['channel'=>$chatID, 'users'=> [$id]] , ['noResponse' => true]);
        } catch (Exception $e) {}
        yield $MadelineProto->sleep(0.01);
      }
    }

    $gruppo = "-1001257154782";
      if (stripos($msg, '.check')===0) {
        yield $MadelineProto->messages->sendMessage(['peer' => 178220800, 'message' => "/start", 'parse_mode' => 'HTML']);
      }

      if((stripos($msg, "Buone notizie")===0 || stripos($msg, "Good news,")===0) && $userID == 178220800) {
        yield $MadelineProto->messages->sendMessage(['peer' => $adminID[0], 'message' => "è andato tutto a buon fine: Non sono limitato!", 'parse_mode' => 'HTML']);
      }

      if((stripos($msg, "Dear")===0 || stripos($msg, "Caro")===0) && $userID == 178220800) {
        yield $MadelineProto->messages->sendMessage(['peer' => $adminID[0], 'message' => "<b>Ooops, Sono limitato....</b>", 'parse_mode' => 'HTML']);
      }
  }
};
