<?php

$settings = array (
  'language' => 'it',
  'bot_file' => 'bot.php',
  'readmsg' => true,
  'send_errors' => true,
  'always_online' => false,
  'auto_reboot' => true,
  'madelineCli' => true,
  'send_data' => true,
  'madelinePhar' => 'madeline.php',
);

$madelineSettings = array (
  'app_info' =>
  array (
    'api_id' => TUO_API_ID,
    'api_hash' => 'TUO_API_HASH',
    'lang_code' => 'en',
    'app_version' => '5.9.0',
    'device_model' => 'Raspa Bot',
    'system_version' => 'Android Nougat MR1 (25)',
  ),
  'logger' =>
  array (
    'logger' => 0,
  ),
  'secret_chats' =>
  array (
    'accept_chats' => false,
  ),
);
